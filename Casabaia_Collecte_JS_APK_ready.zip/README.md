# Casabaia Collecte — édition JavaScript

Reconstruction web/PWA du projet Flutter V3.4 fourni dans l'archive d'origine.

## Fonctionnalités reprises dans cette première version JS
- Tableau de bord et statistiques par secteur.
- 50 points initiaux importés depuis `assets/points.json`.
- Filtrage par secteur, recherche, ajout de points et changement de statut.
- Préparation d'une tournée et optimisation locale par plus proche voisin.
- Estimation indicative de distance et de durée.
- Constats avec type, description, photo et position GPS.
- Clôture des constats.
- Historique des économies.
- Export JSON, export CSV et import de sauvegarde.
- Stockage local dans le navigateur.
- Base PWA et configuration Capacitor pour Android.

## Lancer sur ordinateur
Installer Node.js, puis dans ce dossier :
```bash
npm install
npm run start
```
Ouvrir l'adresse locale affichée par Vite.

## Préparer Android (APK)
Nécessite Node.js, Android Studio et Android SDK :
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Dans Android Studio : Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important
- Cette livraison est un projet source JavaScript, pas un APK compilé.
- Le ZIP Flutter d'origine ne contenait pas de dossier Android prêt à compiler.
- La carte utilise OpenStreetMap en ligne ; elle ne garantit pas un guidage routier.
- L'optimisation de tournée est géographique et indicative, pas un calcul de trajet routier réel.
- Les données sont locales à l'appareil/navigateur. Aucune synchronisation multi-utilisateur ou serveur n'est configurée.
- Les photos de constats sont conservées dans le stockage local du navigateur : prévoir des sauvegardes et éviter les images volumineuses.
- Les fonctions de la version Flutter qui dépendent de services natifs spécifiques doivent être revalidées et complétées dans Android.
